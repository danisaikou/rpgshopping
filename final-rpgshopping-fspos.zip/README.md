User Manual

This RPG Shopping Generator is really extremely straightforward and does not result in much in the way of instruction.

To run, 