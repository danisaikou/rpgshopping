from flask import Flask, render_template, request
import sqlite3
from itertools import groupby

def get_db_connection():
    conn = sqlite3.connect('inventory.db')
    conn.row_factory = sqlite3.Row
    return conn

# Configure application
app = Flask(__name__)
app.config['SECRET_KEY'] = 'pandas escaped from the zoo'

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/index")
def index():
    return render_template("index.html")

@app.route("/form/", methods=["GET", "POST"])
def form():
    return render_template("form.html")

@app.route("/newtown/", methods=["GET", "POST"])
def newtown():
    conn = get_db_connection()
    Size = request.form.get("Size", "%")

    inventory = conn.execute('SELECT i.ItemType, i.ItemSubtype, i.ItemName, i.CostStandard, i.CostExpensive, i.Limited, i.Size, s.ShopType FROM Items i JOIN ShopType s ON i.ShopTypeID = s.ID WHERE Size = "All" OR ? ORDER BY RANDOM()', (Size,)).fetchall()
    ShopType = {}
    for k, g in groupby(inventory, key=lambda t: t['ShopType']):
        ShopType[k] = list(g)

    townNames = conn.execute("SELECT * FROM TownNames ORDER BY RANDOM()").fetchmany(2)

    adventuringsupplies = conn.execute('SELECT i.ItemName, i.CostStandard, i.CostExpensive, i.Size, s.ShopType FROM Items i JOIN ShopType s ON i.ShopTypeID = s.ID WHERE i.ShopTypeID = 1 ORDER BY RANDOM()').fetchmany(10)

    arcaneshop = conn.execute('SELECT i.ItemName, i.CostStandard, i.CostExpensive, i.Size, s.ShopType FROM Items i JOIN ShopType s ON i.ShopTypeID = s.ID WHERE i.ShopTypeID = 2 ORDER BY RANDOM()').fetchmany(5)

    armory = conn.execute('SELECT i.ItemName, i.CostStandard, i.CostExpensive, i.Size, s.ShopType FROM Items i JOIN ShopType s ON i.ShopTypeID = s.ID WHERE i.ShopTypeID = 3 ORDER BY RANDOM()').fetchmany(3)

    # blackmarket = conn.execute('SELECT i.ItemName, i.CostStandard, i.CostExpensive, i.Size, s.ShopType FROM Items i JOIN ShopType s ON i.ShopTypeID = s.ID WHERE i.ShopTypeID = 4 ORDER BY RANDOM()').fetchmany(10)

    blacksmith = conn.execute('SELECT i.ItemName, i.CostStandard, i.CostExpensive, i.Size, s.ShopType FROM Items i JOIN ShopType s ON i.ShopTypeID = s.ID WHERE i.ShopTypeID = 5 ORDER BY RANDOM()').fetchmany(5)

    fletcher = conn.execute('SELECT i.ItemName, i.CostStandard, i.CostExpensive, i.Size, s.ShopType FROM Items i JOIN ShopType s ON i.ShopTypeID = s.ID WHERE i.ShopTypeID = 7 ORDER BY RANDOM()').fetchmany(2)

    foodmarket = conn.execute('SELECT i.ItemName, i.CostStandard, i.CostExpensive, i.Size, s.ShopType FROM Items i JOIN ShopType s ON i.ShopTypeID = s.ID WHERE i.ShopTypeID = 8 ORDER BY RANDOM()').fetchmany(10)

    generalstore = conn.execute('SELECT i.ItemName, i.CostStandard, i.CostExpensive, i.Size, s.ShopType FROM Items i JOIN ShopType s ON i.ShopTypeID = s.ID WHERE i.ShopTypeID = 9 ORDER BY RANDOM()').fetchmany(10)

    inn = conn.execute('SELECT i.ItemName, i.CostStandard, i.CostExpensive, i.Size, s.ShopType FROM Items i JOIN ShopType s ON i.ShopTypeID = s.ID WHERE i.ShopTypeID = 11 ORDER BY RANDOM()').fetchmany(10)

    potions = conn.execute('SELECT i.ItemName, i.CostStandard, i.CostExpensive, i.Size, s.ShopType FROM Items i JOIN ShopType s ON i.ShopTypeID = s.ID WHERE i.ShopTypeID = 14 ORDER BY RANDOM()').fetchmany(3)

    temple = conn.execute('SELECT i.ItemName, i.CostStandard, i.CostExpensive, i.Size, s.ShopType FROM Items i JOIN ShopType s ON i.ShopTypeID = s.ID WHERE i.ShopTypeID = 17 ORDER BY RANDOM()').fetchmany(3)

    transport = conn.execute('SELECT i.ItemName, i.CostStandard, i.CostExpensive, i.Size, s.ShopType FROM Items i JOIN ShopType s ON i.ShopTypeID = s.ID WHERE i.ShopTypeID = 18 ORDER BY RANDOM()').fetchmany(3)

    conn.close()
    return render_template("newtown.html", ShopType=ShopType, townNames=townNames, inventory=inventory, adventuringsupplies=adventuringsupplies, arcaneshop=arcaneshop, armory=armory, blacksmith=blacksmith, fletcher=fletcher, foodmarket=foodmarket, generalstore=generalstore, inn=inn, potions=potions, temple=temple, transport=transport  )

print("Success")
